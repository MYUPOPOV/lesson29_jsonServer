import { first } from "./modules/first";

first()